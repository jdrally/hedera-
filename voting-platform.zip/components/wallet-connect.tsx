"use client"

import { useWallet } from "@solana/wallet-adapter-react"
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui"
import { Button } from "@/components/ui/button"
import { Loader2 } from "lucide-react"

export function WalletConnect() {
  const { connecting } = useWallet()

  return (
    <div className="flex justify-center">
      {connecting ? (
        <Button disabled className="w-full">
          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          Connecting...
        </Button>
      ) : (
        <WalletMultiButton className="wallet-adapter-button-custom" />
      )}
    </div>
  )
}

