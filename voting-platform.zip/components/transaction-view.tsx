"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, Check } from "lucide-react"
import { useConnection } from "@solana/wallet-adapter-react"

interface TransactionViewProps {
  signature: string
}

export function TransactionView({ signature }: TransactionViewProps) {
  const { connection } = useConnection()

  const getExplorerUrl = (signature: string) => {
    // Determine the correct explorer URL based on the network
    const cluster = connection.rpcEndpoint.includes("devnet")
      ? "devnet"
      : connection.rpcEndpoint.includes("testnet")
        ? "testnet"
        : "mainnet-beta"

    return `https://explorer.solana.com/tx/${signature}?cluster=${cluster}`
  }

  return (
    <Card className="border-green-500 dark:border-green-700">
      <CardHeader className="pb-2">
        <CardTitle className="text-green-600 dark:text-green-400 flex items-center">
          <Check className="h-5 w-5 mr-2" />
          Transaction Successful
        </CardTitle>
        <CardDescription>Your transaction has been confirmed on the Solana blockchain</CardDescription>
      </CardHeader>
      <CardContent className="pb-2">
        <div className="text-xs font-mono bg-slate-100 dark:bg-slate-800 p-2 rounded overflow-auto">{signature}</div>
      </CardContent>
      <CardFooter>
        <Button
          variant="outline"
          size="sm"
          className="w-full"
          onClick={() => window.open(getExplorerUrl(signature), "_blank")}
        >
          <ExternalLink className="h-4 w-4 mr-2" />
          View on Solana Explorer
        </Button>
      </CardFooter>
    </Card>
  )
}

