"use client"

import { useState, useEffect } from "react"
import { useWallet } from "@solana/wallet-adapter-react"
import { VotingOptions } from "@/components/voting-options"
import { VotingResults } from "@/components/voting-results"
import { VoterInfo } from "@/components/voter-info"
import { WalletConnect } from "@/components/wallet-connect"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Loader2, ExternalLink } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { useAnchorVoting } from "@/utils/anchor-voting"
import { useConnection } from "@solana/wallet-adapter-react"

export function VotingApp() {
  const { connected, publicKey } = useWallet()
  const { connection } = useConnection()
  const { toast } = useToast()
  const { loading, error, initialized, totalVotes, voterInfo, castVote, refreshState, votingStateAddress } =
    useAnchorVoting()

  const [connecting, setConnecting] = useState(true)
  const [voteError, setVoteError] = useState<string | null>(null)
  const [lastTransaction, setLastTransaction] = useState<string | null>(null)

  // Check if we're connected to the existing voting state
  useEffect(() => {
    if (connected) {
      const timer = setTimeout(() => {
        setConnecting(false)
      }, 2000)

      return () => clearTimeout(timer)
    }
  }, [connected, initialized])

  const handleVote = async (optionId: number) => {
    setVoteError(null)
    setLastTransaction(null)
    try {
      const signature = await castVote(optionId)
      setLastTransaction(signature)
      toast({
        title: "Vote Cast Successfully",
        description: `You voted for option ${optionId}`,
      })
    } catch (err: any) {
      console.error("Vote error:", err)
      setVoteError(err.message)
      toast({
        variant: "destructive",
        title: "Voting Failed",
        description: "There was an error casting your vote. Please check the debug information for details.",
      })
    }
  }

  const handleRefresh = async () => {
    try {
      await refreshState()
      toast({
        title: "Results Updated",
        description: "The voting results have been refreshed",
      })
    } catch (err: any) {
      toast({
        variant: "destructive",
        title: "Refresh Failed",
        description: err.message,
      })
    }
  }

  const getExplorerUrl = (signature: string) => {
    // Determine the correct explorer URL based on the network
    const cluster = connection.rpcEndpoint.includes("devnet")
      ? "devnet"
      : connection.rpcEndpoint.includes("testnet")
        ? "testnet"
        : "mainnet-beta"

    return `https://explorer.solana.com/tx/${signature}?cluster=${cluster}`
  }

  if (!connected) {
    return (
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Connect Your Wallet</CardTitle>
          <CardDescription>Connect your Solana wallet to participate in the voting</CardDescription>
        </CardHeader>
        <CardContent>
          <WalletConnect />
        </CardContent>
      </Card>
    )
  }

  if (connecting && !initialized) {
    return (
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Connecting to Voting System</CardTitle>
          <CardDescription>Please wait while we connect to the existing voting system</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center py-6">
          <Loader2 className="h-8 w-8 animate-spin" />
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="max-w-4xl mx-auto">
      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {voteError && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <div className="font-semibold">Vote Error:</div>
            <div className="text-xs mt-1 max-h-24 overflow-auto">{voteError}</div>
          </AlertDescription>
        </Alert>
      )}

      {lastTransaction && (
        <Card className="mb-6 border-green-500 dark:border-green-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-green-600 dark:text-green-400 flex items-center">
              <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
              Transaction Successful
            </CardTitle>
          </CardHeader>
          <CardContent className="pb-2">
            <p className="text-sm text-muted-foreground">Your vote has been recorded on the Solana blockchain.</p>
            <div className="mt-2 text-xs font-mono bg-slate-100 dark:bg-slate-800 p-2 rounded overflow-auto">
              {lastTransaction}
            </div>
          </CardContent>
          <CardFooter>
            <Button
              variant="outline"
              size="sm"
              className="w-full"
              onClick={() => window.open(getExplorerUrl(lastTransaction), "_blank")}
            >
              <ExternalLink className="h-4 w-4 mr-2" />
              View on Solana Explorer
            </Button>
          </CardFooter>
        </Card>
      )}

      {initialized && (
        <>
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Connected to Voting System</CardTitle>
              <CardDescription>
                You are connected to the voting system at address:
                <code className="block mt-2 p-2 bg-gray-100 dark:bg-gray-800 rounded text-xs overflow-auto">
                  {votingStateAddress.toString()}
                </code>
              </CardDescription>
            </CardHeader>
            <CardFooter>
              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() =>
                  window.open(getExplorerUrl(votingStateAddress.toString()).replace("/tx/", "/address/"), "_blank")
                }
              >
                <ExternalLink className="h-4 w-4 mr-2" />
                View Voting Contract on Solana Explorer
              </Button>
            </CardFooter>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <VotingOptions onVote={handleVote} hasVoted={voterInfo?.hasVoted || false} loading={loading} />

            <VotingResults totalVotes={totalVotes} onRefresh={handleRefresh} loading={loading} />
          </div>

          {voterInfo && <VoterInfo hasVoted={voterInfo.hasVoted} optionSelected={voterInfo.optionSelected} />}
        </>
      )}

      {!initialized && !connecting && (
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle>Connection Failed</CardTitle>
            <CardDescription>
              Could not connect to the voting system. Please try refreshing the page or contact support.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={refreshState} className="w-full">
              Retry Connection
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

