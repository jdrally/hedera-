"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { RefreshCw, Loader2 } from "lucide-react"

interface VotingResultsProps {
  totalVotes: number
  onRefresh: () => Promise<void>
  loading: boolean
}

export function VotingResults({ totalVotes, onRefresh, loading }: VotingResultsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Voting Results</CardTitle>
        <CardDescription>Current results of the ongoing vote</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="text-center py-6">
          <div className="text-5xl font-bold mb-2">{totalVotes}</div>
          <div className="text-muted-foreground">Total Votes Cast</div>
        </div>
      </CardContent>
      <CardFooter>
        <Button variant="outline" className="w-full" onClick={onRefresh} disabled={loading}>
          {loading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <RefreshCw className="h-4 w-4 mr-2" />}
          Refresh Results
        </Button>
      </CardFooter>
    </Card>
  )
}

