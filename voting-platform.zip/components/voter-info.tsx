"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle2 } from "lucide-react"

interface VoterInfoProps {
  hasVoted: boolean
  optionSelected: number
}

export function VoterInfo({ hasVoted, optionSelected }: VoterInfoProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Your Voting Status</CardTitle>
        <CardDescription>Information about your participation in this vote</CardDescription>
      </CardHeader>
      <CardContent>
        {hasVoted ? (
          <div className="flex items-center space-x-2 text-green-600">
            <CheckCircle2 className="h-5 w-5" />
            <span>You have voted for Option {optionSelected}</span>
          </div>
        ) : (
          <div>You have not voted yet</div>
        )}
      </CardContent>
    </Card>
  )
}

