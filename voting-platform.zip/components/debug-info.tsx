"use client"

import { useEffect, useState } from "react"
import { useWallet } from "@solana/wallet-adapter-react"
import { useConnection } from "@solana/wallet-adapter-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useAnchorVoting } from "@/utils/anchor-voting"

export function DebugInfo() {
  const { publicKey, connected } = useWallet()
  const { connection } = useConnection()
  const { programId, votingStateAddress } = useAnchorVoting()
  const [balance, setBalance] = useState<number | null>(null)
  const [rpcEndpoint, setRpcEndpoint] = useState<string>("")
  const [networkStatus, setNetworkStatus] = useState<string>("Checking...")
  const [devnetWallet] = useState<string>("332qWRkz5qDjrtJnTCcUuTkpouhMr1cnaCqQAzsMSq3h")

  useEffect(() => {
    // Get RPC endpoint
    setRpcEndpoint(connection.rpcEndpoint)

    // Check network status
    const checkNetwork = async () => {
      try {
        const blockHeight = await connection.getBlockHeight()
        setNetworkStatus(`Connected (Block Height: ${blockHeight})`)
      } catch (error) {
        console.error("Error checking network:", error)
        setNetworkStatus("Error connecting to network")
      }
    }

    // Get balance if connected
    const fetchBalance = async () => {
      if (connected && publicKey) {
        try {
          const balance = await connection.getBalance(publicKey)
          setBalance(balance / 1000000000) // Convert lamports to SOL
        } catch (error) {
          console.error("Error fetching balance:", error)
          setBalance(null)
        }
      } else {
        setBalance(null)
      }
    }

    checkNetwork()
    fetchBalance()
  }, [connection, publicKey, connected])

  return (
    <Card className="mt-6">
      <CardHeader>
        <CardTitle>Debug Information</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 text-sm">
          <div>
            <strong>Network Status:</strong> {networkStatus}
          </div>
          <div>
            <strong>RPC Endpoint:</strong> {rpcEndpoint}
          </div>
          <div>
            <strong>Program ID:</strong> {programId.toString()}
          </div>
          <div>
            <strong>Devnet Wallet:</strong> {devnetWallet}
          </div>
          <div>
            <strong>Voting State Address:</strong> {votingStateAddress.toString()}
          </div>
          <div>
            <strong>Wallet Connected:</strong> {connected ? "Yes" : "No"}
          </div>
          {publicKey && (
            <div>
              <strong>Public Key:</strong> {publicKey.toString()}
            </div>
          )}
          {balance !== null && (
            <div>
              <strong>Balance:</strong> {balance} SOL
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

