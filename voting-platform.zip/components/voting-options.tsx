"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Check, Loader2 } from "lucide-react"

interface VotingOptionsProps {
  onVote: (optionId: number) => Promise<void>
  hasVoted: boolean
  loading: boolean
}

const OPTIONS = [
  { id: 1, label: "Option 1", description: "Vote for the first option" },
  { id: 2, label: "Option 2", description: "Vote for the second option" },
  { id: 3, label: "Option 3", description: "Vote for the third option" },
]

export function VotingOptions({ onVote, hasVoted, loading }: VotingOptionsProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Cast Your Vote</CardTitle>
        <CardDescription>Select one of the options below to cast your vote</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {OPTIONS.map((option) => (
            <Button
              key={option.id}
              variant="outline"
              className="w-full justify-between h-auto py-3 text-left"
              onClick={() => onVote(option.id)}
              disabled={hasVoted || loading}
            >
              <div>
                <div className="font-medium">{option.label}</div>
                <div className="text-sm text-muted-foreground">{option.description}</div>
              </div>
              {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            </Button>
          ))}
        </div>

        {hasVoted && (
          <div className="mt-4 p-3 bg-green-50 text-green-700 rounded-md flex items-center">
            <Check className="h-5 w-5 mr-2" />
            <span>You have already cast your vote</span>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

