"use client"

import { useState, useEffect } from "react"
import { useToast } from "@/hooks/use-toast"

declare global {
  interface Window {
    solana: any
    solanaWeb3: any
    anchor: any
  }
}

export function useWallet() {
  const [connected, setConnected] = useState(false)
  const [wallet, setWallet] = useState<any>(null)
  const [program, setProgram] = useState<any>(null)
  const { toast } = useToast()

  useEffect(() => {
    // Load Solana and Anchor libraries dynamically
    const loadLibraries = async () => {
      try {
        // Load web3.js
        const web3 = await import("@solana/web3.js")
        window.solanaWeb3 = web3

        // Load anchor
        const anchor = await import("@coral-xyz/anchor")
        window.anchor = anchor

        // Check if wallet is already connected
        if (window.solana?.isPhantom) {
          try {
            const response = await window.solana.connect({ onlyIfTrusted: true })
            handleWalletConnection(response)
          } catch (err) {
            // User has not connected to the app with this wallet before or has revoked trust
            console.log("Wallet not connected:", err)
          }
        }
      } catch (err) {
        console.error("Error loading libraries:", err)
      }
    }

    loadLibraries()
  }, [])

  const initializeWallet = async () => {
    if (!window.solana) {
      toast({
        variant: "destructive",
        title: "Wallet Not Found",
        description: "Please install Phantom wallet extension",
      })
      window.open("https://phantom.app/", "_blank")
      return
    }

    try {
      const response = await window.solana.connect()
      handleWalletConnection(response)
    } catch (err: any) {
      console.error("Error connecting to wallet:", err)
      toast({
        variant: "destructive",
        title: "Connection Failed",
        description: err.message,
      })
    }
  }

  const handleWalletConnection = async (response: any) => {
    try {
      const publicKey = new window.solanaWeb3.PublicKey(response.publicKey.toString())

      // Create provider and program
      const provider = new window.anchor.AnchorProvider(
        new window.solanaWeb3.Connection(process.env.NEXT_PUBLIC_SOLANA_RPC_URL || "https://api.devnet.solana.com"),
        {
          publicKey,
          signTransaction: async (transaction: any) => {
            return await window.solana.signTransaction(transaction)
          },
          signAllTransactions: async (transactions: any[]) => {
            return await window.solana.signAllTransactions(transactions)
          },
        },
        { commitment: "processed" },
      )

      // Set the provider globally
      window.anchor.setProvider(provider)

      // Initialize the program
      const idl = await window.anchor.Program.fetchIdl(
        new window.solanaWeb3.PublicKey("7BwU8mJrTN1EpCaJFnYnFRrxKrW66we6Mgv3hpVeqnbf"),
        provider,
      )

      const program = new window.anchor.Program(
        idl,
        new window.solanaWeb3.PublicKey("7BwU8mJrTN1EpCaJFnYnFRrxKrW66we6Mgv3hpVeqnbf"),
        provider,
      )

      setWallet({ publicKey })
      setProgram(program)
      setConnected(true)

      toast({
        title: "Wallet Connected",
        description: `Connected to ${publicKey.toString().slice(0, 8)}...`,
      })
    } catch (err: any) {
      console.error("Error initializing program:", err)
      toast({
        variant: "destructive",
        title: "Initialization Failed",
        description: err.message,
      })
    }
  }

  return {
    connected,
    wallet,
    program,
    initializeWallet,
  }
}

