"use client"

import { useEffect, useState } from "react"
import { useWallet, useConnection } from "@solana/wallet-adapter-react"
import { PublicKey, SystemProgram, Transaction, TransactionInstruction } from "@solana/web3.js"

// Program ID
const PROGRAM_ID = new PublicKey("7BwU8mJrTN1EpCaJFnYnFRrxKrW66we6Mgv3hpVeqnbf")

// Existing Voting State Address
const EXISTING_VOTING_STATE = new PublicKey("AhJnvCRLGqAKdvamQFhw5FjTj8hWUmZ8WfDc7cQHWYpK")

// Helper function to derive PDA for voter info
export function deriveVoterInfoPDA(voter: PublicKey): PublicKey {
  try {
    const [pda] = PublicKey.findProgramAddressSync([Buffer.from("voter-info"), voter.toBuffer()], PROGRAM_ID)
    return pda
  } catch (error) {
    console.error("Error deriving voter info PDA:", error)
    throw error
  }
}

// Custom hook for direct RPC interactions
export function useDirectRPC() {
  const { connection } = useConnection()
  const wallet = useWallet()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [initialized, setInitialized] = useState(false)
  const [totalVotes, setTotalVotes] = useState(0)
  const [voterInfo, setVoterInfo] = useState<{ hasVoted: boolean; optionSelected: number } | null>(null)

  // Check if the existing voting state exists on component mount
  useEffect(() => {
    if (wallet.publicKey) {
      checkExistingVotingState()
    }
  }, [wallet.publicKey, connection])

  // Check if the existing voting state exists
  const checkExistingVotingState = async () => {
    try {
      console.log("Checking existing voting state:", EXISTING_VOTING_STATE.toString())
      const accountInfo = await connection.getAccountInfo(EXISTING_VOTING_STATE)

      if (accountInfo) {
        console.log("Existing voting state found")
        await fetchVotingState()
      } else {
        console.log("Existing voting state not found")
      }
    } catch (err) {
      console.error("Error checking existing voting state:", err)
    }
  }

  // Fetch the current voting state
  const fetchVotingState = async () => {
    try {
      setLoading(true)
      setError(null)

      // Fetch the account data
      const accountInfo = await connection.getAccountInfo(EXISTING_VOTING_STATE)

      if (!accountInfo) {
        setError("Voting state account not found")
        return null
      }

      // Parse the account data (simplified)
      // Assuming the data structure is: [authority (32 bytes), totalVotes (8 bytes)]
      const totalVotesBuffer = accountInfo.data.slice(32, 40)
      const totalVotes = totalVotesBuffer.readBigUInt64LE(0)

      console.log("Voting state fetched, total votes:", totalVotes.toString())
      setTotalVotes(Number(totalVotes))
      setInitialized(true)

      // Check if the current user has voted
      if (wallet.publicKey) {
        await checkVoterInfo()
      }

      return { totalVotes: Number(totalVotes) }
    } catch (err: any) {
      console.error("Error fetching voting state:", err)
      setError(err.message)
      return null
    } finally {
      setLoading(false)
    }
  }

  // Check if the current user has voted
  const checkVoterInfo = async () => {
    if (!wallet.publicKey) return null

    try {
      const voterInfoAddress = deriveVoterInfoPDA(wallet.publicKey)
      console.log("Checking voter info at:", voterInfoAddress.toString())

      // Fetch the account data
      const accountInfo = await connection.getAccountInfo(voterInfoAddress)

      if (!accountInfo) {
        console.log("Voter info not found, user hasn't voted yet")
        setVoterInfo(null)
        return null
      }

      // Parse the account data (simplified)
      // Assuming the data structure is: [hasVoted (1 byte), optionSelected (1 byte)]
      const hasVoted = accountInfo.data[0] === 1
      const optionSelected = accountInfo.data[1]

      console.log("Voter info found:", { hasVoted, optionSelected })
      setVoterInfo({ hasVoted, optionSelected })

      return { hasVoted, optionSelected }
    } catch (err: any) {
      console.error("Error checking voter info:", err)
      return null
    }
  }

  // Cast a vote using a raw transaction with a specific instruction format
  const castVote = async (optionId: number) => {
    if (!wallet.publicKey || !wallet.signTransaction) {
      setError("Wallet not connected")
      return
    }

    try {
      setLoading(true)
      setError(null)

      const voterInfoAddress = deriveVoterInfoPDA(wallet.publicKey)
      console.log("Casting vote with option:", optionId)
      console.log("Voter info address:", voterInfoAddress.toString())

      // Try a different approach - use a specific instruction format
      // This is based on the Anchor IDL and the error message

      // Create a buffer for the instruction data
      // Format: [discriminator (8 bytes), option_id (1 byte)]

      // Try different discriminator values
      const discriminators = [
        // Try common Anchor discriminator patterns
        Buffer.from([186, 41, 109, 211, 31, 19, 94, 146]), // "cast_vote"
        Buffer.from([245, 154, 124, 254, 83, 45, 104, 52]), // "castVote"
        Buffer.from([57, 157, 129, 41, 30, 230, 125, 96]), // Another pattern
        Buffer.from([148, 91, 101, 189, 76, 125, 144, 2]), // Another pattern
      ]

      let success = false
      let signature = ""

      for (let i = 0; i < discriminators.length; i++) {
        try {
          const discriminator = discriminators[i]
          console.log(`Trying discriminator ${i}:`, Buffer.from(discriminator).toString("hex"))

          const data = Buffer.alloc(9) // 8 bytes for discriminator + 1 byte for option_id
          discriminator.copy(data, 0) // Copy discriminator to the beginning
          data.writeUInt8(optionId, 8) // Write option_id after the discriminator

          // Create the instruction
          const instruction = new TransactionInstruction({
            keys: [
              { pubkey: EXISTING_VOTING_STATE, isSigner: false, isWritable: true },
              { pubkey: wallet.publicKey, isSigner: false, isWritable: false },
              { pubkey: voterInfoAddress, isSigner: false, isWritable: true },
              { pubkey: wallet.publicKey, isSigner: true, isWritable: true },
              { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
            ],
            programId: PROGRAM_ID,
            data,
          })

          // Create and sign transaction
          const transaction = new Transaction().add(instruction)
          transaction.feePayer = wallet.publicKey
          transaction.recentBlockhash = (await connection.getLatestBlockhash()).blockhash

          // Sign with the wallet
          const signedTransaction = await wallet.signTransaction(transaction)

          // Send the transaction
          signature = await connection.sendRawTransaction(signedTransaction.serialize())
          await connection.confirmTransaction(signature)

          console.log(`Vote cast successfully with discriminator ${i}:`, signature)
          success = true
          break
        } catch (err: any) {
          console.error(`Error with discriminator ${i}:`, err)
          // Continue to the next discriminator
        }
      }

      if (!success) {
        throw new Error("All discriminator attempts failed")
      }

      // Refresh the state
      await fetchVotingState()

      return signature
    } catch (err: any) {
      console.error("Error casting vote:", err)
      setError(err.message)
      throw err
    } finally {
      setLoading(false)
    }
  }

  // Refresh the current state
  const refreshState = async () => {
    await fetchVotingState()
  }

  return {
    loading,
    error,
    initialized,
    totalVotes,
    voterInfo,
    castVote,
    refreshState,
    programId: PROGRAM_ID,
    votingStateAddress: EXISTING_VOTING_STATE,
  }
}

