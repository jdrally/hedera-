"use client"

import { useEffect, useState } from "react"
import { useWallet, useConnection } from "@solana/wallet-adapter-react"
import { PublicKey, SystemProgram, Transaction, TransactionInstruction } from "@solana/web3.js"

// Program ID - matches the declare_id! in the contract
const PROGRAM_ID = new PublicKey("7BwU8mJrTN1EpCaJFnYnFRrxKrW66we6Mgv3hpVeqnbf")

// Existing Voting State Address
const EXISTING_VOTING_STATE = new PublicKey("AhJnvCRLGqAKdvamQFhw5FjTj8hWUmZ8WfDc7cQHWYpK")

// Helper function to derive PDA for voter info - matches the seeds in the contract
export function deriveVoterInfoPDA(voter: PublicKey): PublicKey {
  try {
    const [pda] = PublicKey.findProgramAddressSync([Buffer.from("voter-info"), voter.toBuffer()], PROGRAM_ID)
    return pda
  } catch (error) {
    console.error("Error deriving voter info PDA:", error)
    throw error
  }
}

// Custom hook for Anchor program interactions
export function useAnchorVoting() {
  const { connection } = useConnection()
  const wallet = useWallet()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [initialized, setInitialized] = useState(false)
  const [totalVotes, setTotalVotes] = useState(0)
  const [voterInfo, setVoterInfo] = useState<{ hasVoted: boolean; optionSelected: number } | null>(null)

  // Check if the existing voting state exists on component mount
  useEffect(() => {
    if (wallet.publicKey) {
      checkExistingVotingState()
    }
  }, [wallet.publicKey, connection])

  // Check if the existing voting state exists
  const checkExistingVotingState = async () => {
    try {
      console.log("Checking existing voting state:", EXISTING_VOTING_STATE.toString())
      const accountInfo = await connection.getAccountInfo(EXISTING_VOTING_STATE)

      if (accountInfo) {
        console.log("Existing voting state found")
        await fetchVotingState()
      } else {
        console.log("Existing voting state not found")
      }
    } catch (err) {
      console.error("Error checking existing voting state:", err)
    }
  }

  // Fetch the current voting state
  const fetchVotingState = async () => {
    try {
      setLoading(true)
      setError(null)

      // Fetch the account data
      const accountInfo = await connection.getAccountInfo(EXISTING_VOTING_STATE)

      if (!accountInfo) {
        setError("Voting state account not found")
        return null
      }

      // Parse the account data (simplified)
      // Assuming the data structure is: [discriminator (8 bytes) + authority (32 bytes) + totalVotes (8 bytes)]
      const totalVotesBuffer = accountInfo.data.slice(8 + 32, 8 + 32 + 8)
      const totalVotes = totalVotesBuffer.readBigUInt64LE(0)

      console.log("Voting state fetched, total votes:", totalVotes.toString())
      setTotalVotes(Number(totalVotes))
      setInitialized(true)

      // Check if the current user has voted
      if (wallet.publicKey) {
        await checkVoterInfo()
      }

      return { totalVotes: Number(totalVotes) }
    } catch (err: any) {
      console.error("Error fetching voting state:", err)
      setError(err.message)
      return null
    } finally {
      setLoading(false)
    }
  }

  // Check if the current user has voted
  const checkVoterInfo = async () => {
    if (!wallet.publicKey) return null

    try {
      const voterInfoAddress = deriveVoterInfoPDA(wallet.publicKey)
      console.log("Checking voter info at:", voterInfoAddress.toString())

      // Fetch the account data
      const accountInfo = await connection.getAccountInfo(voterInfoAddress)

      if (!accountInfo) {
        console.log("Voter info not found, user hasn't voted yet")
        setVoterInfo(null)
        return null
      }

      // Parse the account data
      // Assuming the data structure is: [discriminator (8 bytes) + hasVoted (1 byte) + optionSelected (1 byte)]
      const hasVoted = accountInfo.data[8] === 1
      const optionSelected = accountInfo.data[9]

      console.log("Voter info found:", { hasVoted, optionSelected })
      setVoterInfo({ hasVoted, optionSelected })

      return { hasVoted, optionSelected }
    } catch (err: any) {
      console.error("Error checking voter info:", err)
      return null
    }
  }

  // Cast a vote using Anchor's instruction format
  const castVote = async (optionId: number) => {
    if (!wallet.publicKey || !wallet.signTransaction) {
      setError("Wallet not connected")
      return
    }

    try {
      setLoading(true)
      setError(null)

      const voterInfoAddress = deriveVoterInfoPDA(wallet.publicKey)
      console.log("Casting vote with option:", optionId)
      console.log("Voter info address:", voterInfoAddress.toString())

      // Load the Anchor library dynamically to avoid SSR issues
      const anchor = await import("@coral-xyz/anchor")

      // Create the instruction data for cast_vote
      // For Anchor, the first 8 bytes are the instruction discriminator (sha256("global:cast_vote")[:8])
      // The discriminator for "cast_vote" is calculated from the method name
      const methodName = "cast_vote"
      const instructionDiscriminator = Buffer.from(
        Array.from(
          new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`global:${methodName}`))),
        ).slice(0, 8),
      )

      // Create a buffer for the instruction data
      // Format: [discriminator (8 bytes), option_id (1 byte)]
      const data = Buffer.alloc(9) // 8 bytes for discriminator + 1 byte for option_id
      instructionDiscriminator.copy(data, 0) // Copy discriminator to the beginning
      data.writeUInt8(optionId, 8) // Write option_id after the discriminator

      console.log("Instruction data:", Buffer.from(data).toString("hex"))

      // Create the instruction with the exact account order from the contract
      const instruction = new TransactionInstruction({
        keys: [
          { pubkey: EXISTING_VOTING_STATE, isSigner: false, isWritable: true },
          { pubkey: wallet.publicKey, isSigner: false, isWritable: false },
          { pubkey: voterInfoAddress, isSigner: false, isWritable: true },
          { pubkey: wallet.publicKey, isSigner: true, isWritable: true },
          { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
        ],
        programId: PROGRAM_ID,
        data,
      })

      // Create and sign transaction
      const transaction = new Transaction().add(instruction)
      transaction.feePayer = wallet.publicKey
      transaction.recentBlockhash = (await connection.getLatestBlockhash()).blockhash

      // Sign with the wallet
      const signedTransaction = await wallet.signTransaction(transaction)

      // Send the transaction
      const signature = await connection.sendRawTransaction(signedTransaction.serialize())
      await connection.confirmTransaction(signature)

      console.log("Vote cast successfully:", signature)

      // Refresh the state
      await fetchVotingState()

      return signature
    } catch (err: any) {
      console.error("Error casting vote:", err)

      // If this is a specific Anchor error, try a fallback approach
      if (err.message && err.message.includes("custom program error: 0x65")) {
        console.log("Trying fallback approach...")
        return castVoteFallback(optionId)
      }

      setError(err.message)
      throw err
    } finally {
      setLoading(false)
    }
  }

  // Fallback method with a different approach to calculate the discriminator
  const castVoteFallback = async (optionId: number) => {
    if (!wallet.publicKey || !wallet.signTransaction) {
      setError("Wallet not connected")
      return
    }

    try {
      setLoading(true)
      setError(null)

      const voterInfoAddress = deriveVoterInfoPDA(wallet.publicKey)
      console.log("Casting vote (fallback) with option:", optionId)

      // Try a different approach to calculate the discriminator
      // This is based on the Anchor IDL format
      // The discriminator is the first 8 bytes of the SHA-256 hash of "global:<method_name>"

      // Hardcoded discriminators for common Anchor methods
      // These are pre-calculated to avoid browser crypto API issues
      const discriminators = {
        // These are example discriminators - we'll try multiple approaches
        cast_vote: Buffer.from([103, 5, 57, 157, 93, 110, 61, 121]),
        castVote: Buffer.from([148, 91, 101, 189, 76, 125, 144, 2]),
      }

      // Try both discriminators
      for (const [methodName, discriminator] of Object.entries(discriminators)) {
        try {
          console.log(`Trying discriminator for "${methodName}"...`)

          // Create a buffer for the instruction data
          const data = Buffer.alloc(9) // 8 bytes for discriminator + 1 byte for option_id
          discriminator.copy(data, 0) // Copy discriminator to the beginning
          data.writeUInt8(optionId, 8) // Write option_id after the discriminator

          // Create the instruction
          const instruction = new TransactionInstruction({
            keys: [
              { pubkey: EXISTING_VOTING_STATE, isSigner: false, isWritable: true },
              { pubkey: wallet.publicKey, isSigner: false, isWritable: false },
              { pubkey: voterInfoAddress, isSigner: false, isWritable: true },
              { pubkey: wallet.publicKey, isSigner: true, isWritable: true },
              { pubkey: SystemProgram.programId, isSigner: false, isWritable: false },
            ],
            programId: PROGRAM_ID,
            data,
          })

          // Create and sign transaction
          const transaction = new Transaction().add(instruction)
          transaction.feePayer = wallet.publicKey
          transaction.recentBlockhash = (await connection.getLatestBlockhash()).blockhash

          // Sign with the wallet
          const signedTransaction = await wallet.signTransaction(transaction)

          // Send the transaction
          const signature = await connection.sendRawTransaction(signedTransaction.serialize())
          await connection.confirmTransaction(signature)

          console.log(`Vote cast successfully with "${methodName}" discriminator:`, signature)

          // Refresh the state
          await fetchVotingState()

          return signature
        } catch (err: any) {
          console.error(`Error with "${methodName}" discriminator:`, err)
          // Continue to the next discriminator
        }
      }

      // If we get here, all discriminators failed
      throw new Error("All discriminator attempts failed")
    } catch (err: any) {
      console.error("Error in fallback vote casting:", err)
      setError(err.message)
      throw err
    } finally {
      setLoading(false)
    }
  }

  // Refresh the current state
  const refreshState = async () => {
    await fetchVotingState()
  }

  return {
    loading,
    error,
    initialized,
    totalVotes,
    voterInfo,
    castVote,
    refreshState,
    programId: PROGRAM_ID,
    votingStateAddress: EXISTING_VOTING_STATE,
  }
}

