"use client"

import { useEffect, useState } from "react"
import { useAnchorWallet, useConnection } from "@solana/wallet-adapter-react"
import { PublicKey, SystemProgram } from "@solana/web3.js"

// Export SystemProgram for convenience
export { SystemProgram }

// Helper function to derive PDA for voter info
export function deriveVoterInfoPDA(voter: PublicKey, programId: PublicKey): PublicKey {
  try {
    const [pda] = PublicKey.findProgramAddressSync([Buffer.from("voter-info"), voter.toBuffer()], programId)
    return pda
  } catch (error) {
    console.error("Error deriving voter info PDA:", error)
    throw error
  }
}

// This is a simplified approach that doesn't try to fetch the IDL
export function useAnchorProgram() {
  const { connection } = useConnection()
  const wallet = useAnchorWallet()
  const [program, setProgram] = useState<any>(null)

  useEffect(() => {
    const initProgram = async () => {
      if (!wallet || !connection) {
        setProgram(null)
        return
      }

      try {
        // Dynamically import Anchor to avoid SSR issues
        const anchor = await import("@coral-xyz/anchor")

        // Create provider
        const provider = new anchor.AnchorProvider(connection, wallet, { commitment: "processed" })

        // Set the provider globally
        anchor.setProvider(provider)

        // Program ID
        const programId = new PublicKey("332qWRkz5qDjrtJnTCcUuTkpouhMr1cnaCqQAzsMSq3h")

        console.log("Using hardcoded IDL")

        // Hardcoded IDL that matches our program structure
        const hardcodedIdl = {
          version: "0.1.0",
          name: "voting_program",
          instructions: [
            {
              name: "initialize",
              accounts: [
                { name: "votingState", isMut: true, isSigner: true },
                { name: "authority", isMut: true, isSigner: true },
                { name: "systemProgram", isMut: false, isSigner: false },
              ],
              args: [],
            },
            {
              name: "castVote",
              accounts: [
                { name: "votingState", isMut: true, isSigner: false },
                { name: "voter", isMut: false, isSigner: false },
                { name: "voterInfo", isMut: true, isSigner: false },
                { name: "payer", isMut: true, isSigner: true },
                { name: "systemProgram", isMut: false, isSigner: false },
              ],
              args: [{ name: "optionId", type: "u8" }],
            },
          ],
          accounts: [
            {
              name: "votingState",
              type: {
                kind: "struct",
                fields: [
                  { name: "authority", type: "publicKey" },
                  { name: "totalVotes", type: "u64" },
                ],
              },
            },
            {
              name: "voterInfo",
              type: {
                kind: "struct",
                fields: [
                  { name: "hasVoted", type: "bool" },
                  { name: "optionSelected", type: "u8" },
                ],
              },
            },
          ],
        }

        try {
          const program = new anchor.Program(hardcodedIdl, programId, provider)
          console.log("Program initialized with hardcoded IDL")
          setProgram(program)
        } catch (error) {
          console.error("Error initializing with hardcoded IDL:", error)
          setProgram(null)
        }
      } catch (error) {
        console.error("Error in Anchor initialization:", error)
        setProgram(null)
      }
    }

    initProgram()
  }, [connection, wallet])

  return program
}

